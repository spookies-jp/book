package com.github.mhendred.face4j.response;

import java.util.List;

import com.github.mhendred.face4j.model.Namespace;


public interface NamespaceResponse
{
	public List<Namespace> getNamespaces ();
}