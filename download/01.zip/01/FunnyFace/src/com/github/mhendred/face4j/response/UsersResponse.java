package com.github.mhendred.face4j.response;

import java.util.List;

public interface UsersResponse
{

	public List<String> getUsers (String namespace);

}