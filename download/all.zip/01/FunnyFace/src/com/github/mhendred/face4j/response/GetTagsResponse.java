package com.github.mhendred.face4j.response;

import java.util.List;

import com.github.mhendred.face4j.model.Photo;

public interface GetTagsResponse
{

	public List<Photo> getPhotos ();

}