#!/usr/bin/env python
# -*- coding: utf-8 -*-

import urllib
from getpass import getpass

url = 'https://www.google.com/accounts/ClientLogin'
email = raw_input('id : ')
passwd = getpass('password : ')
params = {}
params['accountType'] = 'GOOGLE'
params['Email'] = email
params['Passwd'] = passwd
params['service'] = 'ac2dm'
params = urllib.urlencode(params).encode('utf-8')
ret = urllib.urlopen(url, params)
print ret.read().decode('utf-8')

