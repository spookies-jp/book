/*
 * This file is auto-generated.  DO NOT MODIFY.
 * Original file: C:\\Spookies\\work\\android\\Pedometer\\src\\jp\\co\\spookies\\android\\pedometer\\IPedometerService.aidl
 */
package jp.co.spookies.android.pedometer;
public interface IPedometerService extends android.os.IInterface
{
/** Local-side IPC implementation stub class. */
public static abstract class Stub extends android.os.Binder implements jp.co.spookies.android.pedometer.IPedometerService
{
private static final java.lang.String DESCRIPTOR = "jp.co.spookies.android.pedometer.IPedometerService";
/** Construct the stub at attach it to the interface. */
public Stub()
{
this.attachInterface(this, DESCRIPTOR);
}
/**
 * Cast an IBinder object into an jp.co.spookies.android.pedometer.IPedometerService interface,
 * generating a proxy if needed.
 */
public static jp.co.spookies.android.pedometer.IPedometerService asInterface(android.os.IBinder obj)
{
if ((obj==null)) {
return null;
}
android.os.IInterface iin = (android.os.IInterface)obj.queryLocalInterface(DESCRIPTOR);
if (((iin!=null)&&(iin instanceof jp.co.spookies.android.pedometer.IPedometerService))) {
return ((jp.co.spookies.android.pedometer.IPedometerService)iin);
}
return new jp.co.spookies.android.pedometer.IPedometerService.Stub.Proxy(obj);
}
public android.os.IBinder asBinder()
{
return this;
}
@Override public boolean onTransact(int code, android.os.Parcel data, android.os.Parcel reply, int flags) throws android.os.RemoteException
{
switch (code)
{
case INTERFACE_TRANSACTION:
{
reply.writeString(DESCRIPTOR);
return true;
}
case TRANSACTION_getStep:
{
data.enforceInterface(DESCRIPTOR);
int _result = this.getStep();
reply.writeNoException();
reply.writeInt(_result);
return true;
}
case TRANSACTION_getWalkTime:
{
data.enforceInterface(DESCRIPTOR);
int _result = this.getWalkTime();
reply.writeNoException();
reply.writeInt(_result);
return true;
}
}
return super.onTransact(code, data, reply, flags);
}
private static class Proxy implements jp.co.spookies.android.pedometer.IPedometerService
{
private android.os.IBinder mRemote;
Proxy(android.os.IBinder remote)
{
mRemote = remote;
}
public android.os.IBinder asBinder()
{
return mRemote;
}
public java.lang.String getInterfaceDescriptor()
{
return DESCRIPTOR;
}
/**
     * 歩数を取得
     * @return 歩数
     */
public int getStep() throws android.os.RemoteException
{
android.os.Parcel _data = android.os.Parcel.obtain();
android.os.Parcel _reply = android.os.Parcel.obtain();
int _result;
try {
_data.writeInterfaceToken(DESCRIPTOR);
mRemote.transact(Stub.TRANSACTION_getStep, _data, _reply, 0);
_reply.readException();
_result = _reply.readInt();
}
finally {
_reply.recycle();
_data.recycle();
}
return _result;
}
/**
     * 歩いている時間を取得
     * @return 歩いている時間（秒）
     */
public int getWalkTime() throws android.os.RemoteException
{
android.os.Parcel _data = android.os.Parcel.obtain();
android.os.Parcel _reply = android.os.Parcel.obtain();
int _result;
try {
_data.writeInterfaceToken(DESCRIPTOR);
mRemote.transact(Stub.TRANSACTION_getWalkTime, _data, _reply, 0);
_reply.readException();
_result = _reply.readInt();
}
finally {
_reply.recycle();
_data.recycle();
}
return _result;
}
}
static final int TRANSACTION_getStep = (android.os.IBinder.FIRST_CALL_TRANSACTION + 0);
static final int TRANSACTION_getWalkTime = (android.os.IBinder.FIRST_CALL_TRANSACTION + 1);
}
/**
     * 歩数を取得
     * @return 歩数
     */
public int getStep() throws android.os.RemoteException;
/**
     * 歩いている時間を取得
     * @return 歩いている時間（秒）
     */
public int getWalkTime() throws android.os.RemoteException;
}
