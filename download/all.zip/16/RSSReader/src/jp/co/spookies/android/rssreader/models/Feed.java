package jp.co.spookies.android.rssreader.models;

public class Feed {
	private String link;
	private String title;

	public void setLink(String link) {
		this.link = link;
	}

	public String getLink() {
		return link;
	}

	public void setTitle(String title) {
		this.title = title;
	}

	public String getTitle() {
		return title;
	}
}
