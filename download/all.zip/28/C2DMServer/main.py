# -*- coding: utf-8 -*-
from google.appengine.ext import webapp
from google.appengine.ext.webapp import template
from google.appengine.ext.webapp.util import login_required
from google.appengine.ext.webapp.util import run_wsgi_app
from google.appengine.ext import db
from google.appengine.api import users
import os
import urllib
import urllib2

AUTH = 'XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX'

class Device(db.Model):
    owner = db.UserProperty(required=True)
    registration_id = db.StringProperty(required=True)
    saved_date = db.DateTimeProperty(auto_now=True)

class MainHandler(webapp.RequestHandler):
    @login_required
    def get(self):
        '''ホーム画面'''
        values = {}
        values['logout_url'] = users.create_logout_url(self.request.uri)
        path = os.path.join(os.path.dirname(__file__), 'templates/index.html')
        self.response.out.write(template.render(path, values))

    def post(self):
        '''送信'''
        q = Device.all()
        q.filter('owner =', users.get_current_user())
        q.order('saved_date')
        device = q.get()
        if device is None:
            self.error(500)
            return
        headers = {}
        headers['Authorization'] = 'GoogleLogin auth=%s' % AUTH
        headers['Content-type'] = 'application/x-www-form-urlencoded'
        req = urllib2.Request('https://android.apis.google.com/c2dm/send', headers=headers)
        params = {}
        params['registration_id'] = device.registration_id
        params['collapse_key'] = 1
        params = urllib.urlencode(params)
        urllib2.urlopen(req, params)
        self.redirect(self.request.uri)

class RegisterHandler(webapp.RequestHandler):
    def get(self):
        '''端末の登録'''
        email = self.request.get('email')
        id = self.request.get('registration_id')
        if email and id:
            device = Device(owner=users.User(email), registration_id=id)
            device.put()
            self.response.headers['Content-Type'] = 'text/plane'
            self.response.out.write('ok')
        else:
            self.error(500)

def main():
    application = webapp.WSGIApplication(
            [('/', MainHandler),('/register', RegisterHandler)],
            debug=True)
    run_wsgi_app(application)

if __name__ == '__main__':
    main()

